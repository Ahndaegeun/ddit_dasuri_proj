package kr.or.ddit.cus.vo;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CusVO {
	private String cusNo;
	private String cusNm;
	private String addr;
	private String hp;
}
