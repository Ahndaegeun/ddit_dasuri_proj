package kr.or.ddit.car.vo;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CarVO {
	private String carNo;
	private String manuf;
	private int yy;
	private int driDis;
	private String cusNo;
}
