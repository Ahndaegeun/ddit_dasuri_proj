package kr.or.ddit.repSer.vo;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RepSerVO {
	private String empNo;
	private String cusNo;
	private String serNo;
	private int perPay;
	private int repTm;
}
