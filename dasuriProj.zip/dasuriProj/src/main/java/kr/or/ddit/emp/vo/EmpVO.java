package kr.or.ddit.emp.vo;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class EmpVO {
	private String empNo;
	private String nm;
	private String addr;
	private String hp;
}
